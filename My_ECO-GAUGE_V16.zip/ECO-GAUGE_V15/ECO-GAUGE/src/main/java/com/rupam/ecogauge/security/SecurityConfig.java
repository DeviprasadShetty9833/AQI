// File: src/main/java/com/rupam/ecogauge/security/SecurityConfig.java

package com.rupam.ecogauge.security;

import com.rupam.ecogauge.service.CustomOAuth2UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod; // <<<--- ENSURE THIS IMPORT IS PRESENT
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private CustomOAuth2UserService oauthUserService;

    @Autowired
    private CustomAuthenticationSuccessHandler authenticationSuccessHandler; // Autowire the handler

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception { // Remove handler from params if autowired
        http
                .csrf(csrf -> csrf
                        .disable() // Disable CSRF
                )
                .headers(headers -> headers
                        .frameOptions(frameOptions -> frameOptions
                                .disable() // Required for H2 console
                        )
                )
                .authorizeHttpRequests(authz -> authz
                        // --- PUBLIC ACCESS ---
                        .requestMatchers(
                                AntPathRequestMatcher.antMatcher("/login.html"),
                                AntPathRequestMatcher.antMatcher("/signup.html"),
                                AntPathRequestMatcher.antMatcher("/google-auth.html"),
                                AntPathRequestMatcher.antMatcher("/error"),
                                AntPathRequestMatcher.antMatcher("/h2-console/**"),
                                AntPathRequestMatcher.antMatcher("/api/auth/**"), // This covers login, register, and password reset APIs
                                AntPathRequestMatcher.antMatcher("/request-reset.html"), // <-- NEW
                                AntPathRequestMatcher.antMatcher("/reset-password.html"), // <-- NEW
                                AntPathRequestMatcher.antMatcher("/static/**"), // General static assets if needed
                                AntPathRequestMatcher.antMatcher("/css/**"),   // Specific static assets
                                AntPathRequestMatcher.antMatcher("/js/**"),    // Specific static assets
                                AntPathRequestMatcher.antMatcher("/*.html") // Allow access to root html files if needed (e.g., feedback.html)
                                // Add other specific public files or patterns if necessary
                        ).permitAll()

                        // --- USER/AUTHENTICATED ACCESS ---
                        .requestMatchers(
                                AntPathRequestMatcher.antMatcher("/"), // Home page
                                AntPathRequestMatcher.antMatcher("/noise"), // Home page noise toggle alias
                                AntPathRequestMatcher.antMatcher("/maps/AQI_MAP.html"), // Static map file
                                AntPathRequestMatcher.antMatcher("/maps/NOISE_MAP.html"), // Static map file
                                AntPathRequestMatcher.antMatcher("/user_ranking.html"), // Static ranking file
                                AntPathRequestMatcher.antMatcher("/feedback.html"), // Static feedback file (also needs POST rule below)
                                AntPathRequestMatcher.antMatcher(HttpMethod.GET, "/api/stations"),
                                AntPathRequestMatcher.antMatcher(HttpMethod.GET, "/api/user/me")
                        ).authenticated()

                        // --- SPECIFIC POST FOR FEEDBACK (Authenticated users) ---
                        .requestMatchers(
                                AntPathRequestMatcher.antMatcher(HttpMethod.POST, "/api/feedback") // Allow authenticated users to POST feedback
                        ).authenticated()


                        // --- ADMIN ACCESS ---
                        .requestMatchers(
                                AntPathRequestMatcher.antMatcher("/dashboard"), // Admin dashboard page
                                AntPathRequestMatcher.antMatcher("/ranking.html"), // Admin ranking page (if different from user_ranking)
                                // --- UPDATED: Restrict POST, PUT, DELETE /api/stations to ADMIN ---
                                AntPathRequestMatcher.antMatcher(HttpMethod.POST, "/api/stations"),
                                AntPathRequestMatcher.antMatcher(HttpMethod.PUT, "/api/stations/**"),
                                AntPathRequestMatcher.antMatcher(HttpMethod.DELETE, "/api/stations/**"),
                                // --- Feedback GET (viewing) remains ADMIN only ---
                                AntPathRequestMatcher.antMatcher(HttpMethod.GET, "/api/feedback")
                                // Add other ADMIN-specific APIs or pages here
                        ).hasRole("ADMIN")

                        // Default catch-all rule: Any other request requires authentication
                        .anyRequest().authenticated()
                )
                // --- LOGIN CONFIGURATION ---
                .formLogin(form -> form // Local Form Login config
                        .loginPage("/login.html") // Your custom login page
                        .loginProcessingUrl("/api/auth/login") // The URL your form POSTs to
                        .successHandler(authenticationSuccessHandler) // Use custom handler for role-based redirect
                        .permitAll() // Allow everyone to access the login page itself
                )
                .oauth2Login(oauth2 -> oauth2 // OAuth2 Config (Google)
                        .loginPage("/google-auth.html") // Your page prompting Google Sign-In
                        .userInfoEndpoint(userInfo -> userInfo
                                .userService(oauthUserService) // Use custom service to process user info
                        )
                        .successHandler(authenticationSuccessHandler) // Use same custom handler for role-based redirect
                )
                // --- LOGOUT CONFIGURATION (Optional but Recommended) ---
                .logout(logout -> logout
                        .logoutSuccessUrl("/login.html?logout") // Redirect after logout
                        .permitAll()
                );

        return http.build();
    }
}