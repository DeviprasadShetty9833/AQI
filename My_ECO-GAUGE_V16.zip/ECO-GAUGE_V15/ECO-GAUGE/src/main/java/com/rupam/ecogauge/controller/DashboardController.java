package com.rupam.ecogauge.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @GetMapping("/") // Maps the root path to the new home page
    public String showAqiHome() {
        return "AQI_Home.html";
    }

    @GetMapping("/dashboard")
    public String showDashboard() {
        // This is the secured ADMIN landing page.
        return "dashboard.html";
    }

    @GetMapping("/feedback")
    public String showFeedbackForm() {
        return "feedback.html";
    }
}