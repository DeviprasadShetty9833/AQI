package com.rupam.ecogauge.config;

import com.rupam.ecogauge.model.AuthProvider;
import com.rupam.ecogauge.model.Feedback;
import com.rupam.ecogauge.model.StationData;
import com.rupam.ecogauge.model.User;
import com.rupam.ecogauge.repository.FeedbackRepository;
import com.rupam.ecogauge.repository.StationDataRepository;
import com.rupam.ecogauge.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder; // New Import

import java.time.Instant;
import java.util.List;
import java.util.Random;

@Configuration
public class DataSeeder {

    private final Random random = new Random();

    @Bean
    public CommandLineRunner initDatabase(StationDataRepository stationDataRepository,
                                          FeedbackRepository feedbackRepository,
                                          UserRepository userRepository, // New Injection
                                          PasswordEncoder passwordEncoder) { // New Injection
        return args -> {

            // --- USER DATA SEEDING ---

            // 1. Create ADMIN user
            User adminUser = new User();
            adminUser.setEmail("admin@ecogauge");
            adminUser.setName("Admin User");
            adminUser.setPassword(passwordEncoder.encode("admin"));
            adminUser.setProvider(AuthProvider.LOCAL);
            adminUser.setRole("ADMIN"); // Set the ADMIN role
            userRepository.save(adminUser);

            // 2. Create a normal user for testing
            User normalUser = new User();
            normalUser.setEmail("testuser@ecogauge");
            normalUser.setName("Test User");
            normalUser.setPassword(passwordEncoder.encode("password"));
            normalUser.setProvider(AuthProvider.LOCAL);
            normalUser.setRole("USER"); // Default USER role
            userRepository.save(normalUser);

            // --- STATION DATA SEEDING ---
            List<StationData> initialStations = List.of(
                    createReading("Churchgate", "Western", 18.9283, 72.8297, 48.0, 88.0, 35.0, 40.0, 68.0, Instant.now()),
                    createReading("Mumbai Central", "Western", 18.9690, 72.8195, 50.0, 92.0, 38.0, 38.0, 71.0, Instant.now()),
                    createReading("Dadar (W)", "Western", 19.0186, 72.8432, 52.0, 95.0, 40.0, 35.0, 75.0, Instant.now()),
                    createReading("Kandivali", "Western", 19.2081, 72.8554, 45.0, 85.0, 33.0, 41.0, 66.0, Instant.now()),
                    createReading("Mira Road", "Western", 19.2780, 72.8519, 43.0, 82.0, 31.0, 44.0, 64.0, Instant.now()),

                    createReading("CSMT", "Central", 18.9402, 72.8355, 50.0, 93.0, 38.0, 38.0, 70.0, Instant.now()),
                    createReading("Dadar (C)", "Central", 19.0180, 72.8450, 53.0, 96.0, 41.0, 34.0, 77.0, Instant.now()),
                    createReading("Kurla", "Central", 19.0640, 72.8850, 54.0, 98.0, 42.0, 33.0, 80.0, Instant.now()),
                    createReading("Vidyavihar", "Central", 19.0792, 72.9189, 48.0, 90.0, 37.0, 39.0, 73.0, Instant.now()),
                    createReading("Vikhroli", "Central", 19.1171, 72.9463, 49.0, 91.0, 38.0, 37.0, 74.0, Instant.now()),

                    createReading("Govandi", "Harbour", 19.0480, 72.9200, 56.0, 102.0, 44.0, 31.0, 82.0, Instant.now()),
                    createReading("Panvel", "Harbour", 18.9894, 73.1175, 48.0, 88.0, 36.0, 39.0, 67.0, Instant.now()),
                    createReading("Seawoods-Darave", "Harbour", 19.0200, 73.0010, 42.0, 80.0, 31.0, 43.0, 65.0, Instant.now()),
                    createReading("Khandeshwar", "Harbour", 18.9700, 73.1000, 45.0, 85.0, 33.0, 40.0, 68.0, Instant.now())
            );
            stationDataRepository.saveAll(initialStations);

            // --- FEEDBACK SEEDING ---
            List<Feedback> initialFeedback = List.of(
                    createFeedback("Rahul Sharma", "rahul.s@example.com", "Western", "Borivali", "The AQI alerts are very useful. The historical charts load quickly!"),
                    createFeedback("Priya Singh", "priya.s@example.com", "Central", "Thane", "The dashboard layout is confusing. Can you simplify the navigation bar?"),
                    createFeedback("Amit Patel", "amit.p@example.com", "Harbour", "Panvel", "The map view link doesn't work. Please fix the map feature.")
            );
            feedbackRepository.saveAll(initialFeedback);

            System.out.println("Seeded " + (userRepository.count()) + " users, " + initialStations.size() + " stations and " + initialFeedback.size() + " feedback entries.");
        };
    }
    // ... rest of existing DataSeeder methods ...
    private StationData createReading(String name, String line, double lat, double lon, double pm25, double pm10, double no2, double o3, double noise, Instant timestamp) {
        String aqiCat = categorizeAqi(pm25, pm10, no2, o3);
        int aqiValue = calculateAQI(pm25, pm10, no2, o3);
        String dominant = determineDominant(pm25, pm10, no2, o3);
        String noiseCat = categorizeNoise(noise);

        return new StationData(null, name, line, lat, lon, aqiValue, aqiCat, dominant, noise, noiseCat, pm25, pm10, no2, o3, timestamp);
    }

    private Feedback createFeedback(String name, String email, String region, String location, String message) {
        Feedback f = new Feedback();
        f.setName(name);
        f.setEmail(email);
        f.setRegion(region);
        f.setLocation(location);
        f.setMessage(message);
        f.setTimestamp(Instant.now().minusSeconds(random.nextInt(86400 * 7))); // Random timestamp within the last week
        return f;
    }

    // --- Helper Logic to mirror front-end for initial seeding ---

    private int calculateAQI(double pm25, double pm10, double no2, double o3) {
        // Simplified logic: just take the max value scaled to 1-150 range.
        double maxPollutant = Math.max(pm25, Math.max(pm10 / 2, Math.max(no2 * 2, o3)));
        return (int) Math.min(Math.round(maxPollutant * 1.5), 250);
    }

    private String categorizeAqi(double pm25, double pm10, double no2, double o3) {
        int aqi = calculateAQI(pm25, pm10, no2, o3);
        if (aqi <= 50) return "Good";
        if (aqi <= 100) return "Moderate";
        if (aqi <= 150) return "Poor";
        if (aqi <= 200) return "Unhealthy";
        return "Severe";
    }

    private String categorizeNoise(double noise) {
        if (noise <= 70) return "Moderate";
        if (noise <= 85) return "High";
        return "Dangerous";
    }

    private String determineDominant(double pm25, double pm10, double no2, double o3) {
        if (pm25 > 50) return "PM2.5";
        if (pm10 > 90) return "PM10";
        if (no2 > 40) return "NO2";
        if (o3 > 50) return "O3";
        return "N/A";
    }
}