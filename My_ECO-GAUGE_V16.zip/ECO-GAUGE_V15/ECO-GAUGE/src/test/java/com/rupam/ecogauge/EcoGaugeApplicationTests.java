package com.rupam.ecogauge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoGaugeApplicationTests {

    @Test
    void contextLoads() {
    }

}
