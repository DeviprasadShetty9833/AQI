package com.rupam.ecogauge.dto;
import lombok.Data;
@Data
public class PasswordResetRequest {
    private String email;
}