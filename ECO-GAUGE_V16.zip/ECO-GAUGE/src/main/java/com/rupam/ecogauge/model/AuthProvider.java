package com.rupam.ecogauge.model;

public enum AuthProvider {
    LOCAL,
    GOOGLE
}