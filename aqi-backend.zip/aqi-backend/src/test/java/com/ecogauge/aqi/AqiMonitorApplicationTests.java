package com.ecogauge.aqi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AqiMonitorApplicationTests {

    @Test
    void contextLoads() {
    }
}
