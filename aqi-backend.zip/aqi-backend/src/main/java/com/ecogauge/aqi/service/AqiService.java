package com.ecogauge.aqi.service;

import com.ecogauge.aqi.model.AqiData;
import com.ecogauge.aqi.repository.AqiRepository;
import org.springframework.beans.factory.annotation.Value; // Import this
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate; // Import this
import org.springframework.web.util.UriComponentsBuilder; // Import this

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AqiService {

    private final AqiRepository repository;

    // Inject values from application.properties
    @Value("${waqi.api.url}")
    private String waqiApiUrl;

    @Value("${waqi.api.token}")
    private String waqiApiToken;

    public AqiService(AqiRepository repository) {
        this.repository = repository;
    }

    // --- Keep your existing methods ---
    public AqiData save(AqiData data) {
        data.setTimestamp(LocalDateTime.now());
        return repository.save(data);
    }

    public List<AqiData> getAllData() {
        return repository.findAll();
    }

    public List<AqiData> getByCity(String city) {
        return repository.findByCity(city);
    }

    public List<AqiData> getByStation(String station) {
        return repository.findByStation(station);
    }
    // --- End of existing methods ---


    // --- ADD THIS NEW METHOD ---
    /**
     * Fetches AQI data from the external WAQI API.
     * @param lat Latitude
     * @param lon Longitude
     * @return The raw data object from the external API.
     */
    public Object fetchAqiFromExternalApi(double lat, double lon) {
        RestTemplate restTemplate = new RestTemplate();
        String url = UriComponentsBuilder.fromUriString(waqiApiUrl + "/geo:" + lat + ";" + lon + "/")
                .queryParam("token", waqiApiToken)
                .toUriString();

        // The 'Object.class' tells RestTemplate to just return the parsed JSON
        // as a map-like object, which is perfect for a simple proxy.
        return restTemplate.getForObject(url, Object.class);
    }
}
