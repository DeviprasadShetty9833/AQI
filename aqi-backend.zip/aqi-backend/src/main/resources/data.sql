INSERT INTO aqi_data (city, station, latitude, longitude, aqi, category, timestamp)
VALUES ('Mumbai', 'Bandra Kurla Complex', 19.0544, 72.8691, 120, 'Unhealthy for Sensitive Groups', CURRENT_TIMESTAMP);

INSERT INTO aqi_data (city, station, latitude, longitude, aqi, category, timestamp)
VALUES ('Mumbai', 'Powai', 19.1197, 72.9056, 85, 'Moderate', CURRENT_TIMESTAMP);

INSERT INTO aqi_data (city, station, latitude, longitude, aqi, category, timestamp)
VALUES ('Mumbai', 'Worli', 19.0176, 72.8118, 160, 'Unhealthy', CURRENT_TIMESTAMP);
